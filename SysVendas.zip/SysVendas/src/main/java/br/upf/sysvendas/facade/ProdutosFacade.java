package br.upf.sysvendas.facade;

import br.upf.sysvendas.entity.ProdutosEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;

/**
 * Fachada responsável por realizar operações de persistência
 * para a entidade ProdutosEntity.
 */
@Stateless
public class ProdutosFacade extends AbstractFacade<ProdutosEntity> {

    @PersistenceContext(unitName = "SysVendasPU")
    private EntityManager em;

    /**
     * Construtor padrão.
     * Informa a superclasse qual é a entidade gerenciada.
     */
    public ProdutosFacade() {
        super(ProdutosEntity.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Retorna todos os produtos cadastrados.
     * @return Lista de ProdutosEntity
     */
    public List<ProdutosEntity> buscarTodos() {
        return super.findAll();
    }
}
