package br.upf.sysvendas.controller;

import br.upf.sysvendas.entity.ProdutosEntity;
import br.upf.sysvendas.facade.ProdutosFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Controlador responsável pela lógica de interface e ações de CRUD
 * relacionadas à entidade ProdutosEntity.
 */
@Named(value = "produtosController")
@SessionScoped
public class ProdutosController implements Serializable {

    private static final long serialVersionUID = 1L;

    @EJB
    private ProdutosFacade produtosFacade;

    private ProdutosEntity produto;
    private ProdutosEntity selected;

    /**
     * Retorna a lista de produtos cadastrados.
     * @return Lista de ProdutosEntity
     */
    public List<ProdutosEntity> getProdutoList() {
        return produtosFacade.buscarTodos();
    }

    public ProdutosEntity getProduto() {
        return produto;
    }

    public void setProduto(ProdutosEntity produto) {
        this.produto = produto;
    }

    public ProdutosEntity getSelected() {
        return selected;
    }

    public void setSelected(ProdutosEntity selected) {
        this.selected = selected;
    }

    /**
     * Prepara um novo produto para cadastro.
     * @return Nova instância de ProdutosEntity
     */
    public ProdutosEntity prepareAdicionar() {
        produto = new ProdutosEntity();
        return produto;
    }

    /**
     * Adiciona um novo produto no banco.
     */
    public void adicionarProduto() {
        produto.setDataCadastro(new Date());
        persist(PersistAction.CREATE, "Produto incluído com sucesso!");
        produto = new ProdutosEntity(); // Limpa formulário
    }

    /**
     * Atualiza o produto selecionado.
     */
    public void editarProduto() {
        persist(PersistAction.UPDATE, "Produto alterado com sucesso!");
        selected = null;
    }

    /**
     * Remove o produto selecionado do banco.
     */
    public void excluirProduto() {
        persist(PersistAction.DELETE, "Produto excluído com sucesso!");
        selected = null;
    }

    /**
     * Realiza a operação de persistência conforme o tipo informado.
     * @param persistAction Ação a ser executada (CREATE, UPDATE, DELETE)
     * @param successMessage Mensagem de sucesso exibida ao usuário
     */
    private void persist(PersistAction persistAction, String successMessage) {
        try {
            if (persistAction != null) {
                switch (persistAction) {
                    case CREATE:
                        produtosFacade.create(produto);
                        break;
                    case UPDATE:
                        produtosFacade.edit(selected);
                        break;
                    case DELETE:
                        produtosFacade.remove(selected);
                        break;
                }
                addSuccessMessage(successMessage);
            }
        } catch (Exception ex) {
            String msg = (ex.getCause() != null) ? ex.getCause().getLocalizedMessage() : ex.getLocalizedMessage();
            if (msg != null && !msg.isBlank()) {
                addErrorMessage(msg);
            } else {
                addErrorMessage("Erro na persistência!");
            }
        }
    }

    /**
     * Exibe uma mensagem de erro para o usuário.
     * @param msg Mensagem de erro
     */
    private static void addErrorMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);
        FacesContext.getCurrentInstance().addMessage(null, facesMsg);
    }

    /**
     * Exibe uma mensagem de sucesso para o usuário.
     * @param msg Mensagem de sucesso
     */
    private static void addSuccessMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg);
        FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg);
    }

    /**
     * Enum que representa as ações de persistência.
     */
    public enum PersistAction {
        CREATE,
        DELETE,
        UPDATE
    }

    /**
     * Retorna a lista de unidades disponíveis (exibida no selectOneMenu).
     * @return Array de unidades
     */
    public String[] getUnidades() {
        return new String[]{"UN", "KG", "L", "CX", "PCT"};
    }
}
