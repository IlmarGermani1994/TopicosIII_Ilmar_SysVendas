package br.upf.sysvendas.controller;

import br.upf.sysvendas.entity.UsuariosEntity;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Named(value = "usuariosController")
@SessionScoped
public class UsuariosController implements Serializable {

    private UsuariosEntity usuario = new UsuariosEntity();
    private UsuariosEntity selected;
    private List<UsuariosEntity> usuarioList = new ArrayList<>();

    public UsuariosEntity getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuariosEntity usuario) {
        this.usuario = usuario;
    }

    public UsuariosEntity getSelected() {
        return selected;
    }

    public void setSelected(UsuariosEntity selected) {
        this.selected = selected;
    }

    public List<UsuariosEntity> getUsuarioList() {
        return usuarioList;
    }

    public void setUsuarioList(List<UsuariosEntity> usuarioList) {
        this.usuarioList = usuarioList;
    }

    private int gerarId() {
        return usuarioList.size() + 1;
    }

    public void novo() {
        usuario = new UsuariosEntity();
    }

    public void adicionarUsuario() {
        usuario.setId(gerarId());
        usuario.setDataCadastro(new Date());
        usuarioList.add(usuario);
        exibirMensagem("Usuário cadastrado com sucesso: " + usuario.getNome());
        usuario = new UsuariosEntity();
    }

    public void editarUsuario() {
        int index = usuarioList.indexOf(selected);
        usuarioList.set(index, selected);
        exibirMensagem("Usuário alterado com sucesso: " + selected.getNome());
        selected = null;
    }

    /**
     * Método utilizado para excluir um usuário da tabela
     */
    public void excluirUsuario() {
        int index = usuarioList.indexOf(selected);
        usuarioList.remove(index);
        exibirMensagem("Usuário excluído com sucesso: " + selected.getNome());
        selected = null;
    }

    private void exibirMensagem(String mensagem) {
        FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso!", mensagem);
        FacesContext.getCurrentInstance().addMessage(null, fm);
    }
}
