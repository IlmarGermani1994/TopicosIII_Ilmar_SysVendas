package br.upf.sysvendas.controller;

import br.upf.sysvendas.entity.UsuariosEntity;
import br.upf.sysvendas.facade.UsuariosFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Named(value = "usuariosController")
@SessionScoped
public class UsuariosController implements Serializable {

    private static final long serialVersionUID = 1L;

    @EJB
    private UsuariosFacade ejbFacade;

    private UsuariosEntity usuario;
    private UsuariosEntity selected;

    /**
     * Retorna a lista de usuários do banco.
     */
    public List<UsuariosEntity> getUsuarioList() {
        return ejbFacade.buscarTodos();
    }

    public UsuariosEntity getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuariosEntity usuario) {
        this.usuario = usuario;
    }

    public UsuariosEntity getSelected() {
        return selected;
    }

    public void setSelected(UsuariosEntity selected) {
        this.selected = selected;
    }

    /**
     * Prepara um novo usuário para cadastro.
     */
    public UsuariosEntity prepareAdicionar() {
        usuario = new UsuariosEntity();
        return usuario;
    }

    /**
     * Adiciona o usuário no banco.
     */
    public void adicionarUsuario() {
        usuario.setDataCadastro(new Date());
        usuario.setDatahoraReg(new Date());
        persist(PersistAction.CREATE, "Usuário incluído com sucesso!");
        usuario = new UsuariosEntity();
    }

    /**
     * Edita o usuário selecionado.
     */
    public void editarUsuario() {
        persist(PersistAction.UPDATE, "Usuário alterado com sucesso!");
        selected = null;
    }

    /**
     * Exclui o usuário selecionado.
     */
    public void excluirUsuario() {
        persist(PersistAction.DELETE, "Usuário excluído com sucesso!");
        selected = null;
    }

    /**
     * Realiza a ação de persistência conforme o tipo.
     */
    private void persist(PersistAction persistAction, String successMessage) {
        try {
            if (persistAction != null) {
                switch (persistAction) {
                    case CREATE:
                        ejbFacade.create(usuario);
                        break;
                    case UPDATE:
                        ejbFacade.edit(selected);
                        break;
                    case DELETE:
                        ejbFacade.remove(selected);
                        break;
                }
                addSuccessMessage(successMessage);
            }
        } catch (Exception ex) {
            String msg = (ex.getCause() != null)
                    ? ex.getCause().getLocalizedMessage()
                    : ex.getLocalizedMessage();
            if (msg != null && !msg.isBlank()) {
                addErrorMessage(msg);
            } else {
                addErrorMessage("Erro na persistência do usuário.");
            }
        }
    }

    /**
     * Exibe mensagem de erro.
     */
    private static void addErrorMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);
        FacesContext.getCurrentInstance().addMessage(null, facesMsg);
    }

    /**
     * Exibe mensagem de sucesso.
     */
    private static void addSuccessMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg);
        FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg);
    }

    /**
     * Enum para definir o tipo de ação persistente.
     */
    public enum PersistAction {
        CREATE,
        DELETE,
        UPDATE
    }
}
