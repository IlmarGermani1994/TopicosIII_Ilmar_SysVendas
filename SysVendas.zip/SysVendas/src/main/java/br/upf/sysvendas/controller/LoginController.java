package br.upf.sysvendas.controller;

import br.upf.sysvendas.entity.UsuariosEntity;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.io.Serializable;

@Named(value = "loginController")
@SessionScoped
public class LoginController implements Serializable {

    private UsuariosEntity usuario;

    public LoginController() {
    }

    @PostConstruct
    public void init() {
        prepareAutenticarUsuario();
    }

    public void prepareAutenticarUsuario() {
        usuario = new UsuariosEntity();
    }

    public UsuariosEntity getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuariosEntity usuario) {
        this.usuario = usuario;
    }

    public String validarLogin() {
        if ("usuario@gmail.com".equals(usuario.getEmail()) &&
            "123".equals(usuario.getSenha())) {
            return "/usuarios.xhtml?faces-redirect=true";
        } else {
            FacesMessage fm = new FacesMessage(
                FacesMessage.SEVERITY_ERROR,
                "Falha no Login!",
                "Email ou senha incorreto!");
            FacesContext.getCurrentInstance().addMessage(null, fm);
            return null;
        }
    }
}
