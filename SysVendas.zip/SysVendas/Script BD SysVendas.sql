CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(100) NOT NULL,
    data_cadastro DATE NOT NULL,
    ativo BOOLEAN NOT NULL
);

INSERT INTO usuarios (nome, email, senha, data_cadastro, ativo)
VALUES ('Administrador', 'usuario@gmail.com', '123', CURRENT_DATE, TRUE);

select * from usuarios;



-- 1) Criação da tabela em PostgreSQL
CREATE TABLE produtos (
  codigo         SERIAL           PRIMARY KEY,
  nome           VARCHAR(100)     NOT NULL,
  valor          NUMERIC(15,2)    NOT NULL,
  unidade        VARCHAR(20)      NOT NULL,
  data_cadastro  DATE             NOT NULL
);

-- 2) Inserção de dados de exemplo
INSERT INTO produtos (nome,      valor,    unidade, data_cadastro) VALUES
  ('Banana',       3.99,    'KG',    CURRENT_DATE),
  ('Maçã',         5.49,    'KG',    CURRENT_DATE),
  ('Leite',        4.50,    'LT',    CURRENT_DATE),
  ('Pão Francês',  0.50,    'UN',    CURRENT_DATE),
  ('Arroz Branco',20.00,    'KG',    CURRENT_DATE);

-- 3) Verificação
SELECT * FROM produtos;
